
<!DOCTYPE html>
<html class="no-js">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />
    <title>Form validation</title>
    <link rel="stylesheet" type="text/css" media="screen" href="form.css">
    <script src="main.js"></script>
        
        <!--Github Website-->
	 <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Raghav Singh</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
       
        <!-- Google Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Lato:400,700,400italic,300' rel='stylesheet' type='text/css'>

		<!-- all css here -->
		
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="css/git/bootstrap.min.css">
        <!-- Animated text css -->
		<link rel="stylesheet" href="css/git/animated.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="css/git/owl.carousel.css">
        <link rel="stylesheet" href="css/git/owl.transitions.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="css/git/font-awesome.min.css">
        <!-- animate css -->
        <link rel="stylesheet" href="css/git/animate.css">
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
		<!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">

		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.html"><i class="icon-airplane"></i>Travel</a></h1>
					<!-- START #fh5co-menu-wrap -->
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li class="active"><a href="index.html">Home</a></li>
							<!--<li><a href="flight.html">Flights</a></li>-->
							<li><a href="hotel.html">Train Schedule</a></li>
							<li><a href="car.html">Fare Enquiry</a></li>
							<li><a href="newlogin.html">Login/Signup</a></li>
							<li><a href="contact.html">Contact</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</header>


         <div class="bottomcontent" id="bottomcont">
          <div class="regform">
	         <form id="frm" action="userdatapost.php" method="post">
		     <center>
		
		      <input type="text" name="fname" id="fname" placeholder="First Name">
		      <input type="text" name="lname" id="lname" placeholder="Last Name">
		      <input type="email" name="email" id="email" placeholder="Email Id">
		      <input type="tel" name="number" min="1" max="10" id="number" placeholder="Mobile No">
		      <input type="text" name="date" id="date" placeholder="DOB dd/mm/yy">
		      <input type="password" name="password" id="password" placeholder="Password">
		      <input type="password" name="cpassword" id="cpwd" placeholder="Confirm Password">
		      <input type="submit" name="submit" value="Submit">
		      <input type="reset" name="reset" value="Reset">
             </center>
             </form>
         </div>
         <div class="logform">
           <form method="POST" action="loginprocess.php" class="loginfrm">
	       <table>
			<input type="text" name="username" placeholder="Username" id="user"></td>
			<input type="Password" name="password" placeholder="Password" id="pass"></td>
			<input type="submit" name="bttLogin" value="Login" placeholder="&nbsp;" id="logbtn"></td>
			<input type="reset" name="reset" value="Cancel" id="logbtn"></td>
	   	   </table>
	   	</form>
		</div>
	</div>
		<!-- End contact Area -->
        <!-- Start Footer bottom Area -->
           <footer>
			<div id="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-dribbble2"></i></a>
							</p>
							<p>Copyright 2018<a href="#"></a>. All Rights Reserved. <br>Made with <i class="icon-heart3"></i> by Raghvendra</a>
						</div>
					</div>
				</div>
			</div>
		</footer>

	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->
	 
	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<!-- Google Map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
	<script src="js/google_map.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	</body>
</html>



<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

        
        <!--Github Website-->
	 <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>BookMyJourney</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
       
        <!-- Google Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Lato:400,700,400italic,300' rel='stylesheet' type='text/css'>

		<!-- all css here -->
		
		<!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="css/git/bootstrap.min.css">
        <!-- Animated text css -->
		<link rel="stylesheet" href="css/git/animated.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="css/git/owl.carousel.css">
        <link rel="stylesheet" href="css/git/owl.transitions.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="css/git/font-awesome.min.css">
        <!-- animate css -->
        <link rel="stylesheet" href="css/git/animate.css">
		<!-- style css -->
		<link rel="stylesheet" href="style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="css/responsive.css">
		<!-- modernizr css -->
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>

 
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">

		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.php">BooMyJourney</a></h1>
					<!-- START #fh5co-menu-wrap -->
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li class="active"><a href="index.php">Home</a></li>
							<!--<li><a href="flight.html">Flights</a></li>-->
							<li><a href="schedule.php">Train Schedule</a></li>
							<li><a href="login.php">Login/Signup</a></li>
							<li><a href="contact.php">Contact</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</header>

<div id="contact" class="contact-area area-padding">
            <div class="head-overly"></div>
		    <div class="container">
                <div class="row contact-inner">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <div class="Cont-content">
                            <h4 class="intro-head">Contact me</h4>
                        </div>
                        <div class="map-zone">
                            <!-- Map area -->
                            <div class="map-area">
                            </div><!-- End Map area -->
                            <div class="contact-info">
                                <div class="contact-icons">
                                    <h2 style="color:#ff4500 ">Contact info</h2>
                                    <ul>
                                        <li>
                                            <strong style="font-size: 17px;">Ahmedabad, India.</strong>
                                             
                                        </li>
                                        <li>
                                            <strong style="font-size: 17px;">+919574547152</strong>
                                            
                                        </li>
                                        <li>
                                            <strong style="font-size: 17px;">Raghav26897@gmail.com</strong>
                                            
                                        </li>
                                    </ul>
                                </div>
                                <!-- <div class="icons-bottom text-center">
                                    <ul>
                                        <li><a href="https://www.facebook.com/raghvendrars"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="https://github.com/Raghav26897"><i class="fa fa-github-square"></i></a></li>
                                        <li><a href="https://www.instagram.com/__raghav__singh__/"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="https://www.linkedin.com/in/raghavendra-singh-a14109154/"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div> -->
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <div class="contact-form">
                            <div class="Cont-content">
                                <h4 class="intro-head">Leave a massege</h4>
                            </div>
                            <div class="row contact-bg">
                                <form action="mail.php" method="post">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <input name="name" type="text" placeholder="Name (required)" />
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <input name="email" type="email" placeholder="Email (required)" />
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <input name="subject" type="text" placeholder="Subject" />
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <textarea name="message" id="message" cols="30" rows="10" placeholder="Message"></textarea>
                                        <input type="submit" value="Submit Form" />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
		    </div>
		</div>
		<!-- End contact Area -->
        <!-- Start Footer bottom Area -->
            <footer>
			<div id="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="https://twitter.com/Vishen_Raghav"><i class="icon-twitter2"></i></a>
								<a href="https://www.facebook.com/raghvendrars"><i class="icon-facebook2"></i></a>
								<a href="https://www.instagram.com/_rajawat_raghav_/?hl=en"><i class="icon-instagram"></i></a>
								<a href="https://github.com/Raghav26897"><i class="icon-github"></i></a>
							</p>
							<p>Copyright 2018<a href="#"></a>. All Rights Reserved. <br>Made with <i class="icon-heart3">
                                </i><a> by Raghvendra</a>
						</div>
					</div>
				</div>
			</div>
		</footer>
	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->

	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	<!-- Google Map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
	<script src="js/google_map.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	</body>
</html>

